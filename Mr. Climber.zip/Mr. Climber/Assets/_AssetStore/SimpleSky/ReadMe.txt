Simple Sky

Offset the UV's on the SimpleSky material to change time of day